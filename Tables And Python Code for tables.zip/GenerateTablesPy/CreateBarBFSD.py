import csv
## Use Codecs to decode csv files cleanly
import codecs

import os

import random
#Useful for random
from random import randrange
#Useful to have time
import time
from datetime import datetime, timedelta

def main():
    print("Hello world")
    Beers = []

    #Nice with parameter

    print "\nBEERS\n"

    with codecs.open('Beers.csv','rb',encoding = "utf-8-sig") as csvfile:
        for i in csvfile:
	    Beers.append(i.split(','))
    print Beers,len(Beers)
    #Have Beers-Manf list

    #Beers = GenBeerPrices(Beers)

    #return

    #return

    print "\nNOW BARS\n"
 
    Bars = []
    with codecs.open('bars.csv','rb',encoding = "utf-8",errors='ignore') as csvfile:
        for i in csvfile:
            i = i.translate("\n\r\t\ufeff")
	    i = i.encode('ascii','ignore')
	    Bars.append(i.split(','))
	    #Bars.append((''.join(i.split(','))).split('\t'))
    print Bars

    Beers = GenBeerPrices(Beers,len(Bars))

    #return

    SoftDrinks = []   
 
    print "\nNOW SOFTDRINKS\n"

    with codecs.open('SoftDrinks.csv','rb',encoding = "utf-8-sig") as csvfile:
        for i in csvfile:
            i = i.translate("\n\r\t")
	    i = i.translate(u'')
	    i = i.encode('ascii','ignore')
	    i = i.split(',')
	    if len(i[0])<=1:
		#print "I:",i[0]
		break
	    SoftDrinks.append(i)
    print SoftDrinks
    #Have SoftDrink-Manf list

    Foods = []

    print "\nNOW FOODS\n" 

    with codecs.open('Foods.csv','rb',encoding = "utf-8-sig") as csvfile:
        for i in csvfile:
            Foods.append(i.split(','))
    print Foods

    BarHours = []

    print "\n NOW BAR HOURS\n"

    with codecs.open('Bars+Hours.csv','rb',encoding = "utf-8-sig") as csvfile:
        for i in csvfile:
	    i = i.translate("\n\r\t")     
	    BarHours.append(i.split(',')[1:3])
    
    print BarHours

    Drinkers = []

    print "\n NOW DRINKERS\n"

    with codecs.open('Drinkers.csv','rb',encoding = "utf-8-sig") as csvfile:
        for i in csvfile:
            i = i.translate("\n\r\t")
            Drinkers.append(i.split(',')[0:6])

    print Drinkers

    #return

    #CONSTRAINTS:
    # Drinker can only frequent bars in same state
    # Beers must be different price than beer in another bar, by any margin
    # Transactions are issued only in bar hour times


    #Create Food Sells Bar,Food,Hours,Price,Tax, this just defines all possible sells a bar can do of a food, general just populate list for each bar
    FoodSells = [] 
    
    print "\n\nTEST TIMESTAMP RAND WITHIN RANGE"
 
    n = 0
  
    FoodSells = GenSellsTable(Bars,Foods,1)

    BeerSells = GenSellsTable(Bars,Beers,2)

    SoftDrinkSells = GenSellsTable(Bars,SoftDrinks,3)


    #return


    StoreSells(SoftDrinkSells,3) 
   
    StoreSells(FoodSells,1)

    StoreSells(BeerSells,2)

    #return

    #print "FoodSells", FoodSells
    #print "BeerSells:", BeerSells
    #print "SoftDrinks:", SoftDrinkSells

    FoodTransactions = []
    BeerTransactions = []
    SoftDrinkTransactions = []

    FoodTransactions = GenTransactionTable(Drinkers,FoodSells,BarHours)
    BeerTransactions = GenTransactionTable(Drinkers,BeerSells,BarHours)
    SoftDrinkTransactions = GenTransactionTable(Drinkers,SoftDrinkSells,BarHours)

    #return

    #print "Food Transactions:",FoodTransactions
    #print "Beer Transactions:",BeerTransactions
    #print "Soft Drink Transactions:",SoftDrinkTransactions

    StoreTransactionTable(FoodTransactions,1)
    StoreTransactionTable(BeerTransactions,2)
    StoreTransactionTable(SoftDrinkTransactions,3)
  
    #Frequents = GetFrequentsTable(Bars,Drinkers)

    #Likes = GetLikesTable(Beers,Drinkers,BeerSells)

    #StoreTable(Frequents,1)
    #StoreTable(Likes,2)

    #rand.uniform(d,d)
    #randrange(i,i)

#Get Random Time between two
def randomize_time(start_timestamp,end_timestamp):
    try:
        print "Start time:",PrintTime(start_timestamp)," End Time:",PrintTime(end_timestamp)," Random time between:", (time.strftime('%H:%M:%S',time.localtime(randrange(start_timestamp,end_timestamp))))	 
        return time.strftime('%H:%M:%S',time.localtime(randrange(start_timestamp,end_timestamp)))
    except:
	temp = start_timestamp
	start_timestamp = end_timestamp
	end_timestamp = temp
	print "Start time:",PrintTime(start_timestamp)," End Time:",PrintTime(end_timestamp)," Random time between:", (time.strftime('%H:%M:%S',time.localtime(randrange(start_timestamp,end_timestamp))))
        return time.strftime('%H:%M:%S',time.localtime(randrange(start_timestamp,end_timestamp)))


def StoreTable(T,Case):

    OpenF = ""
    if Case==1:
	OpenF = "Frequents.csv"
    else:
	OpenF = "Likes.csv"
    try:
        os.remove(OpenF)
    except:
	print "None Exists"
    for i in T:
	#print i	
 	for j in i:
	    #print j
	    with open(OpenF,'a') as resultFile:
	        resultFile.writelines("\r")
		resultFile.writelines((',').join(j))
'''
    with open(OpenF,'a') as resultFile:
                        wr = csv.writer(resultFile, dialect='excel')
                        #resultFile.seek(0,2)
                        if Case==1:
                            #if C1L%2==0:
                            resultFile.writelines("\r")
                            resultFile.writelines((',').join(Row).replace('\r','').replace('\n',''))
   
'''

def GetFrequentsTable(T1,T2):
    print "\nGEN FREQUENTS TABLE\n"
    Freq = []
    #Bar Tuples
    for i in T1:
	App = []
	#Drinker chosen in same state as T1's
        Cap = randrange(11,55)	
        ChooseCount = 0

	Visited = []

	while ChooseCount<Cap:
	    DC = ChooseDrinker(T2,i[3])
	    print "Drinker Chosen for state:",i[3]," ",DC

	    if [DC,i[0]] not in Visited:
	        App.append([DC,i[0]])
		Visited.append([DC,i[0]])

	    ChooseCount+=1
	Freq.append(App)
	#print i
    print "Frequents:",Freq
    return Freq

#Beer must be within any bar w/ same state
#Beersells list, beers is string name
def BeerMatchState(BeerSells,Beer,MyState):
    for i in BeerSells:
	#print "\n",i,"\n"
	for j in i[1:]:
	    #print "Bar State:",i[0][3],"My State:",MyState
	    #print j
	    for l in j:
		#print "Bar Beer",l[0][0]," My Beer:",Beer
		if i[0][3]==MyState and l[0][0]==Beer:
		    #print "FOUND MATCH"
		    return True
    return False
def GetLikesTable(Beers,Drinkers,BeerSells):
    Likes = []
    #Beer Tuples
    for i in Beers:
	App = []
	#Drinker chooses random beers liked
	#B = ChooseBeersLte(Beers,Drinkers,BeerSells,2)
	#print B
	for k in Drinkers:
	    #Choose some beers in state and some out of state
	    B = ChooseBeersLte(Beers,None,None,2)

	    B2 = (ChooseBeersLte(Beers,k[2],BeerSells,1))
	    
	    #Stores all visited drinker+beers
	    Visited = []

	    for b in B:
		if b not in Visited:
	            App.append([k[0],b])
		    Visited.append(b)
	    for b in B2:
		if b not in Visited:
		    App.append([k[0],b])
		    Visited.append(b)
	
	Likes.append(App)    
    print "\nLIKES\n",Likes
    return Likes
#Store this Transaction Table on file
#File1 FoodTransactions.csv
#File2 BeerTransactions.csv
#File3 SoftDrinkTransactions.csv
def StoreTransactionTable(TransactionTable,Case):
   
    TCount = 0
 
    OpenF = ""

    if Case==1:
        OpenF = "FoodTransactions.csv"
    elif Case==2:
        OpenF = "BeerTransactions.csv"
    elif Case==3:
        OpenF = "SoftDrinkTransactions.csv"

    try:
        os.remove(OpenF) 
    except:
	print "New File"

    C1L = 0

    ct = 0

    for i in TransactionTable:
	
	#All bar + transactions
	#print "BAR + Transactions:",i
	
	#Bar
	#print "Bar:",i[0][0]
	print "\nFILL TRANSACTIONS\n"
	for k in i: 
            #All Transactions
 	    print "\nTransactions",TCount,":",k[0:] 
	    #First store bar into file,
	    print "Bar:",k[0][0]
	    #Then store drinker in to file,
	    #Then store consumable in file,
	    #Then store price
	    #Then store tip
	    #Then store time given
	    for l in k[1:]:
		#Iterate to each person that did transaction with bar for food		
		for m in l:
		    Row = [str(k[0][0]),str(m[0]),m[1][0][0],str(m[1][1]),str(m[2]),m[3]]
		    print "Drinker:",m[0]
		    print "Consumable:",m[1][0][0],m[1][1]
		    print "Tip:",m[2]
	 	    print "Time:",m[3]	
	    
		    with open(OpenF,'a') as resultFile:
			wr = csv.writer(resultFile, dialect='excel')
			#resultFile.seek(0,2)
			if Case==1:
			    #if C1L%2==0:
			    resultFile.writelines("\r")
                            resultFile.writelines((',').join(Row).replace('\r','').replace('\n',''))
			    C1L+=1
			elif Case==2:
			    resultFile.writelines("\r")
			    resultFile.writelines((',').join(Row))
			elif Case==3:
			    resultFile.writelines("\r")
                            resultFile.writelines((',').join(Row))

			#resultFile.writelines("\n")

		    #return
	TCount+=1
	print ""

    
#Create Transaction tables for each type of tableSells
def GenTransactionTable(Drinkers,SellsTable,BarHours):
   
    TransactionTable = []

    Bh = 0

    start_timestamp = time.mktime(time.strptime('01:33:00','%I:%M:%S'))
    end_timestamp = time.mktime(time.strptime('02:44:00','%I:%M:%S'))

    Add24 = timedelta(hours=24)
   
    VisitedPrice = []

    #randomize_time(start_timestamp,end_timestamp)
 
    for i in SellsTable:

	App = []
        #Bar is in i[0]
	#for Bar in i[0]:
	print "Bar:",i[0]," Bar Hours:", BarHours[Bh]
	#App.append(i[0])

  	ST = time.mktime(time.strptime(BarHours[Bh][0].encode('ascii','ignore'),'%H:%M:%S'))
        ED = time.mktime(time.strptime(BarHours[Bh][1].encode('ascii','ignore'),'%H:%M:%S'))


	#time.strftime('%H:%M:%S',time.localtime(randrange(start_timestamp,end_timestamp)))
	Twelve = False

	if(ED<ST):
	    #ED = time.mktime(time.strptime( (AddDay(BarHours[Bh][1].encode('ascii','ignore') ) ),'%H:%M:%S'  ) ) 
	    #BarHours[Bh][1] = AddDay(BarHours[Bh][1])
	    #print "NEW BAR HOURS:",BarHours[Bh]
	    Twelve = True
	    ST = time.mktime(time.strptime(AddDay(BarHours[Bh][0].encode('ascii','ignore')),'%H:%M:%S'))

	    ED = time.mktime(time.strptime(AddDay(BarHours[Bh][1].encode('ascii','ignore')),'%H:%M:%S'))

	    #ED = time.mktime(time.strptime(BarHours[Bh][1].encode('ascii','ignore'),'%H:%M:%S')) 
	    #os.exit(0)


	#Any Comsumable is in i[1]
	T = 0.0

	#if i[1][1] in VisitedPrice or i[1][1]<=0:
            #print i[1][1], "IS VISITED!!!!!!!!!!!"
	    #continue
	    #os.exit(1)
	    #i[1][1]+=random.uniform(0.25,3.33)
        
	#VisitedPrice.append(i[1][1])

	#Generate certain amount of consumables
	for Consumable in i[1]:
	    TransactionCount = randrange(0,10)
	    A = []
	    
  	    #if Consumable[1] in VisitedPrice:
                #Consumable[1]+=random.uniform(0.25,3.33)
            #VisitedPrice.append(Consumable[1])	    

	    #Generate X randomized transactions per consumable item in Bar...
	    while TransactionCount<20:
	        T = Tip(Consumable[1])
		#if Consumable[1] in VisitedPrice:
		    #Consumable[1]+=random.uniform(0.25,3.33)
		#VisitedPrice.append(Consumable[1])
	        print "Consumable:",Consumable[0]," Price + Tax:",Consumable[1], " Price + Tax + Tip:",Consumable[1]+T
	        DC = ChooseDrinker(Drinkers,i[0][3])
	        print "Drinker In State:",i[0][3]," Chosen: ",DC
	        #Add drinker that lives in same state!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	        #A.append([DC])
	        ###################################################STOPPPPPPPPPPPPP
	        #A.append([Consumable,T])
	        #Now add in random time within bar hours 
	        if( not Twelve):
		    print "Start:",PrintTime(ST)," End:",PrintTime(ED)
	            A.append([DC,Consumable,T,randomize_time(ST,ED)])
		else:
		    R = randomize_time(ST,ED)
			
		    print "TIME BETWEEN:",AddDay(PrintTime(ST))," AND:",AddDay(PrintTime(ED)), " ",AddDay(R)
		    A.append([DC,Consumable,T,AddDay(R)])
		    #os.exit(0)

		#A.append([randomize_time(ST,ED))
 	        TransactionCount+=1
            App.append([i[0],A])
	TransactionTable.append(App)
	#if Bh==1:
	    #return TransactionTable
	Bh+=1
    return TransactionTable

def AddDay(time_string):
    the_time = datetime.strptime(time_string, '%H:%M:%S')
    new_time = the_time + timedelta(hours=12)
    return new_time.strftime('%H:%M:%S')

def StoreSells(Sells,Case):
    OpenF = ""
    if Case==1:
	OpenF = "FoodSells.csv"
    elif Case==2:
	OpenF = "BeerSells.csv"
    elif Case==3:
	OpenF = "SoftDrinkSells.csv"
   
    try:
        os.remove(OpenF)
    except:
	print "None to remove"
 
    for i in Sells:
	print "BAR:",i[0]
	for k in i[1:]:
	    print "Sells:",k	
	    for l in k:
		print "info:",l
		Bar = i[0][0]
	   	Drink = l[0][0]
		Price = l[1]
		Row = [Bar,Drink,str(Price)]
		with open(OpenF,'a') as resultFile:
		    if Case==1:
			resultFile.writelines("\r")
                        resultFile.writelines((',').join(Row).replace('\r','').replace('\n',''))	
		    else:
		        resultFile.writelines("\r")
		        resultFile.writelines((',').join(Row))

'''
with open(OpenF,'a') as resultFile:
                        wr = csv.writer(resultFile, dialect='excel')
                        #resultFile.seek(0,2)
                        if Case==1:
                            #if C1L%2==0:
                            resultFile.writelines("\r")
                            resultFile.writelines((',').join(Row).replace('\r','').replace('\n',''))

'''

def Max(G,VisitedPrice):
    for i in VisitedPrice:
	#print "COMPARE",i," WITH",G
	if G<=i:
	    #os.exit(0)
	    return False
    return True

def Maximum(VisitedPrice):
    maxi = -1
    for i in VisitedPrice:
	#print "COMPARE",i," WITH",G
	if i > maxi:
	    maxi = i
    return maxi

def GenBeerPrices(Beers,BarsLen):
    
    BeerP = []
    
    VisitedPrice = []


    j = 0
    X = 0.012
    #GetBeerPrice()
    for i in Beers:
        #X=0.01
	k = 0
	#VisitedPrice = []
	App = []
	while k<BarsLen:
	    G = 0.0
	    Unique = False
	    while not Unique:
		M = Maximum(VisitedPrice)
		if M==-1:
		    G += X + GetBeerPrice()
		else:
		    G += X + M
		G = round(G,2)
		if(Max(G,VisitedPrice) and G not in VisitedPrice):
		    #VisitedPrice.append(G)
		    break
		#else:
		    #X = (X + X/(j*j*99999*j*j))
	    VisitedPrice.append(G)
	    App.append([i[0],i[1],G])
	    k+=1
	j+=1
	X += ( X/((70*j)))
	BeerP.append(App)  	
    for l in BeerP:
	#l[0][2] = l[0][2]-10
	for p in l:
	    if(p[2]<2):
		print "TOO LOW BEERS!!!"
		os.exit(-1)
	    p[2] = round(p[2],2)
    
    print "NEW BEERS:",BeerP
    
    input("Press Enter if satisfied, ctrl+C to quit")

    #os.exit(0)
    return BeerP
#Generate table given bar + (food,beer,or soft drink)
def GenSellsTable(T1,T2,Case):
    List = []
    u = 0
    n = 0 
    V = []
    for i in T1:

        ######BAR#########
        print "Bar:",i#,"From["
        u=n
        S = []
        S.append(i)
        ######BAR########


        ###### CONSUMABLE  #######
	if(Case==1):
            S.append(ChooseFoods(T2,List))
	    #T2 is foods list
	elif Case==2:
	    S.append(ChooseBeers(T2,V))
        elif Case==3:
	    S.append(ChooseDrinks(T2,List))

	###### CONSUMABLE #######


        ###### Price#####
	#Price is given to each food
	#####Price######

	n+=1
        #print "]"
        List.append(S)
    #os.exit(-1)
    print "\nSELLS:\n",List
    return List

def PriceNotIn(G,List):
    for i in List:
	for j in i[1:]:
	    #print "???:",j
	    for l in j:
		#print "IF",l[1]," ==",G	
		if(l[1]==G):
		    return False
    return True

def Tip(D):
    divisor = random.uniform(0.25,0.40)
    return round(D*divisor,2)

#Choose a random drinker from list of all drinkers in the state
#If doesn't exist, return None
def ChooseDrinker(Drinkers,State):
    DrinkersInState = []
    for i in Drinkers:
        if i[2] == State:
	    #print "DRINKER IN STATE:",i
	    DrinkersInState.append(i[0])
    
    return random.choice(DrinkersInState)

#Each bar should have 10-25 drinks
def ChooseDrinks(L,List):
    DrinkCount = randrange(10,25)
    i=0
    DrinkList = []
    while(i<DrinkCount):
	UniquePrice = False
	G = 0.0 
	while not UniquePrice:
	    G = GetDrinkPrice()
	    if(PriceNotIn(G,List)):
		break
        DrinkList.append([[random.choice(L)[0]],GetDrinkPrice()])
        i+=1

    return DrinkList

#Return collection of beers
def ChooseBeersLte(Beers,State,BeerSells,Case):
    BeerCount = randrange(10,25)
    i=0
    BeerList = []
    while(i<BeerCount):
        if Case==1:
	    RB = random.choice(Beers)[0]
	    if BeerMatchState(BeerSells,RB,State):
		BeerList.append(RB)	    
	    #Choose beers likes within state
	elif Case==2:
	    BeerList.append(random.choice(Beers)[0])
        i+=1
    return BeerList

#Each bar should have 10-25 beers
def ChooseBeers(Beers,VisitedPrice):
    BeerCount = randrange(10,25)
    i=0
    BeerList = []
    while(i<BeerCount):
	UniquePrice = False
	R = 0.0
	RL  = (random.choice(Beers))
	R = random.choice(RL)[2]
	while R in VisitedPrice:
	     R  = random.choice(RL)[2]
	VisitedPrice.append(R)

	print "RANDOM CHOICE:",R," BEER:",RL[0][0]
	#for u in RL:
	    #u.remove(u[2])
	#print "CUT RL:",RL
	BeerList.append([[RL[0][0]],R])

        i+=1
    return BeerList

#Each bar should have 8-18 foods
def ChooseFoods(L,List):
    FoodCount = randrange(8,18)
    i=0
    FoodList = []
    while(i<FoodCount):
	UniquePrice = False
        G = 0.0
        while not UniquePrice:
            G = GetFoodPrice()
            if(PriceNotIn(G,List)):
                break

	FoodList.append([random.choice(L),GetFoodPrice()])
	i+=1
    return FoodList

def GetDrinkPrice():
    return round(PriceTax(random.uniform(2.50,5.65)),2)

def GetBeerPrice():
    return round(PriceTax(random.uniform(6.30,14.45)),2)

def GetFoodPrice():
    return round(PriceTax(random.uniform(5.25,13.50)),2)

def PriceTax(d):
    return d+(d*(7/100))

def hour_rounder(t):
    # Rounds to nearest hour by adding a timedelta hour if minute >= 30
    return (t.replace(second=0, microsecond=0, minute=0, hour=t.hour)
               +timedelta(hours=t.minute//30))

#Print Time given timee object
def PrintTime(timee):
     #print time.strftime('%H:%M:%S', time.localtime(timee))
     return time.strftime('%H:%M:%S', time.localtime(timee))
if __name__ == "__main__":
    main()	
